<div class="AuthenticationConfigure Slice" rel="dashboard/authentication/configure">
   <div class="Info">
      <?php echo $this->Data('ConfigureMessage'); ?>
   </div>
</div>